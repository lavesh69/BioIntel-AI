# SYNTHETIC DEMO DATA

This workspace contains simulated data generated for demonstration and testing. It must not be used for scientific, clinical, diagnostic, regulatory, or publication decisions.

- Module: experimental_design
- Scenario: missing_control
- Random seed: 219173
- Dataset size: small
- Allowed use: demonstration, testing, training
- Prohibited use: scientific conclusion, clinical decision, diagnosis, treatment, regulatory submission, publication claim

The files use neutral synthetic identifiers and contain no copied user rows, patient identifiers, real citations, clinical claims or proprietary records.
